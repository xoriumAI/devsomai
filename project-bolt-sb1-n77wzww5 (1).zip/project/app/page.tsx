"use client";

import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WalletDashboard } from "@/components/wallet-dashboard";
import { WalletList } from "@/components/wallet-list";
import { ChatInterface } from "@/components/chat-interface";
import { CreateWalletDialog } from "@/components/create-wallet-dialog";
import { LayoutDashboard, Wallet, MessageSquare } from "lucide-react";
import { useWalletStore } from "@/store/wallet-store";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Home() {
  const { loadWallets } = useWalletStore();
  const [activeTab, setActiveTab] = useState("dashboard");

  useEffect(() => {
    loadWallets();
  }, [loadWallets]);

  return (
    <div className="container mx-auto p-4 space-y-4">
      <header className="flex justify-between items-center py-6">
        <div>
          <h1 className="text-3xl font-bold">Solana Wallet Manager</h1>
          <p className="text-muted-foreground">Secure and efficient wallet management</p>
        </div>
        <div className="flex items-center gap-4">
          <ThemeToggle />
          <CreateWalletDialog />
        </div>
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="dashboard">
            <LayoutDashboard className="mr-2 h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="wallets">
            <Wallet className="mr-2 h-4 w-4" />
            Wallets
          </TabsTrigger>
          <TabsTrigger value="chat">
            <MessageSquare className="mr-2 h-4 w-4" />
            Chat
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" asChild>
          <div className={activeTab === "dashboard" ? "block" : "hidden"}>
            <WalletDashboard />
          </div>
        </TabsContent>

        <TabsContent value="wallets" asChild>
          <div className={activeTab === "wallets" ? "block" : "hidden"}>
            <WalletList />
          </div>
        </TabsContent>

        <TabsContent value="chat" asChild>
          <div className={activeTab === "chat" ? "block" : "hidden"}>
            <ChatInterface />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}