"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, RefreshCcw, ArrowRight, Coins } from "lucide-react";
import { useWalletStore } from "@/store/wallet-store";
import { useToast } from "@/hooks/use-toast";
import { Connection, PublicKey, Keypair, Transaction, SystemProgram } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, getAssociatedTokenAddress, createAssociatedTokenAccountInstruction, createTransferInstruction } from "@solana/spl-token";
import bs58 from 'bs58';

const SOLANA_RPC_URL = "https://solana-api.instantnodes.io/token-RRGPc9gLXCcxjGKwzEwf4RQ9ejdocJum";
const connection = new Connection(SOLANA_RPC_URL, {
  commitment: 'confirmed',
  confirmTransactionInitialTimeout: 60000,
  wsEndpoint: 'wss://solana-api.instantnodes.io/token-RRGPc9gLXCcxjGKwzEwf4RQ9ejdocJum'
});

interface TokenBalance {
  mint: string;
  amount: number;
  decimals: number;
  symbol?: string;
}

// Helper function to add delay between requests
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function swapTokenPercentage(
  walletPublicKey: string,
  percentage: number,
  getPrivateKey: (publicKey: string) => Promise<string>,
  toast: any
) {
  if (!walletPublicKey) {
    throw new Error("Wallet address is required");
  }

  if (percentage <= 0 || percentage > 100) {
    throw new Error("Invalid percentage value");
  }

  try {
    // Get the private key
    const privateKey = await getPrivateKey(walletPublicKey);
    if (!privateKey) {
      throw new Error("Private key not found");
    }

    // Create keypair from private key
    const keypair = Keypair.fromSecretKey(bs58.decode(privateKey));

    // Add delay before fetching token accounts
    await delay(2000);

    // Get token accounts with retry logic
    let tokenAccounts;
    let retries = 3;
    while (retries > 0) {
      try {
        tokenAccounts = await connection.getParsedTokenAccountsByOwner(
          keypair.publicKey,
          { programId: TOKEN_PROGRAM_ID }
        );
        break;
      } catch (error) {
        retries--;
        if (retries === 0) throw error;
        await delay(5000); // Wait 5 seconds before retrying
      }
    }

    if (!tokenAccounts?.value || tokenAccounts.value.length === 0) {
      throw new Error("No token accounts found in this wallet");
    }

    // Find the token with the highest value
    let highestValueToken = null;
    let highestValue = 0;

    for (const account of tokenAccounts.value) {
      const amount = account.account.data.parsed.info.tokenAmount.uiAmount;
      if (amount > highestValue) {
        highestValue = amount;
        highestValueToken = {
          mint: account.account.data.parsed.info.mint,
          amount: amount,
          decimals: account.account.data.parsed.info.tokenAmount.decimals,
          address: account.pubkey.toBase58() // Fixed: Using pubkey from the account directly
        };
      }
    }

    if (!highestValueToken) {
      throw new Error("No tokens with positive balance found in wallet");
    }

    // Calculate amount to swap based on percentage
    const amountToSwap = (highestValueToken.amount * percentage) / 100;
    if (amountToSwap <= 0) {
      throw new Error("Amount to swap is too small");
    }

    toast({
      title: "Swap Initiated",
      description: `Preparing to swap ${amountToSwap.toFixed(highestValueToken.decimals)} tokens (${highestValueToken.mint.slice(0, 8)}...) to SOL`,
    });

    return true;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Failed to swap tokens");
  }
}

export function BundleTokenSwap() {
  const [isLoading, setIsLoading] = useState(false);
  const [tokenBalances, setTokenBalances] = useState<Record<string, TokenBalance[]>>({});
  const { wallets, getPrivateKey } = useWalletStore();
  const { toast } = useToast();

  const bundleWallets = wallets.filter(w => w.group === 'bundles' && !w.archived);
  const firstWallet = bundleWallets[0];

  const fetchTokenBalances = async () => {
    setIsLoading(true);
    const newTokenBalances: Record<string, TokenBalance[]> = {};

    try {
      for (const wallet of bundleWallets) {
        const walletTokens: TokenBalance[] = [];
        
        // Add delay between each wallet's token fetch
        await delay(2000);

        try {
          const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
            new PublicKey(wallet.publicKey),
            { programId: TOKEN_PROGRAM_ID }
          );

          for (const account of tokenAccounts.value) {
            if (account.account.data.parsed.info.tokenAmount.uiAmount > 0) {
              walletTokens.push({
                mint: account.account.data.parsed.info.mint,
                amount: account.account.data.parsed.info.tokenAmount.uiAmount,
                decimals: account.account.data.parsed.info.tokenAmount.decimals,
              });
            }
          }

          if (walletTokens.length > 0) {
            // Sort tokens by amount value (highest first)
            walletTokens.sort((a, b) => b.amount - a.amount);
            newTokenBalances[wallet.publicKey] = walletTokens;
          }
        } catch (error) {
          console.warn(`Error fetching tokens for wallet ${wallet.publicKey}:`, error);
          // Continue with next wallet even if one fails
          continue;
        }
      }

      setTokenBalances(newTokenBalances);
      
      if (Object.keys(newTokenBalances).length === 0) {
        toast({
          title: "No tokens found",
          description: "No SPL tokens found in bundle wallets",
        });
      }
    } catch (error) {
      console.error('Error fetching token balances:', error);
      toast({
        title: "Error",
        description: "Failed to fetch token balances",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const sendAllToFirstWallet = async () => {
    if (!firstWallet) {
      toast({
        title: "Error",
        description: "No destination wallet found in bundle group",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const destinationPubkey = new PublicKey(firstWallet.publicKey);

      for (const [walletPublicKey, tokens] of Object.entries(tokenBalances)) {
        // Skip the first wallet as it's the destination
        if (walletPublicKey === firstWallet.publicKey) continue;

        const privateKey = await getPrivateKey(walletPublicKey);
        if (!privateKey) {
          console.warn(`Private key not found for wallet ${walletPublicKey}`);
          continue;
        }

        const sourceKeypair = Keypair.fromSecretKey(bs58.decode(privateKey));

        for (const token of tokens) {
          try {
            // Add delay between token transfers
            await delay(2000);

            const sourceATA = await getAssociatedTokenAddress(
              new PublicKey(token.mint),
              sourceKeypair.publicKey
            );

            const destinationATA = await getAssociatedTokenAddress(
              new PublicKey(token.mint),
              destinationPubkey
            );

            // Check if destination account exists
            const destinationAccount = await connection.getAccountInfo(destinationATA);
            
            const transaction = new Transaction();

            // Create destination ATA if it doesn't exist
            if (!destinationAccount) {
              transaction.add(
                createAssociatedTokenAccountInstruction(
                  sourceKeypair.publicKey,
                  destinationATA,
                  destinationPubkey,
                  new PublicKey(token.mint)
                )
              );
            }

            // Add transfer instruction
            transaction.add(
              createTransferInstruction(
                sourceATA,
                destinationATA,
                sourceKeypair.publicKey,
                token.amount * Math.pow(10, token.decimals)
              )
            );

            const signature = await connection.sendTransaction(transaction, [sourceKeypair]);
            await connection.confirmTransaction(signature);

            toast({
              title: "Transfer successful",
              description: `Transferred ${token.amount} tokens (${token.mint.slice(0, 8)}...) to first wallet`,
            });

            // Add delay after successful transfer
            await delay(2000);
          } catch (error) {
            console.error(`Error transferring token ${token.mint}:`, error);
            toast({
              title: "Error",
              description: `Failed to transfer token ${token.mint.slice(0, 8)}...`,
              variant: "destructive",
            });
            // Add delay after error before continuing
            await delay(5000);
          }
        }
      }
    } catch (error) {
      console.error('Error in transfer process:', error);
      toast({
        title: "Error",
        description: "Failed to complete token transfers",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      fetchTokenBalances(); // Refresh balances after transfers
    }
  };

  return (
    <Card className="mb-4">
      <CardContent className="pt-6">
        <div className="flex justify-between items-center mb-4">
          <div className="space-y-1">
            <h3 className="text-lg font-medium">Bundle Tokens</h3>
            <p className="text-sm text-muted-foreground">
              Manage SPL tokens in bundle wallets
            </p>
          </div>
          <div className="space-x-2">
            <Button
              variant="outline"
              onClick={fetchTokenBalances}
              disabled={isLoading || bundleWallets.length === 0}
            >
              <RefreshCcw className="mr-2 h-4 w-4" />
              Scan Tokens
            </Button>
            <Button
              variant="outline"
              onClick={sendAllToFirstWallet}
              disabled={isLoading || Object.keys(tokenBalances).length === 0 || !firstWallet}
            >
              <ArrowRight className="mr-2 h-4 w-4" />
              Send All to First Wallet
            </Button>
            <Button
              onClick={() => {}} // Placeholder for swap functionality
              disabled={isLoading || Object.keys(tokenBalances).length === 0}
            >
              <Coins className="mr-2 h-4 w-4" />
              Swap All to SOL
            </Button>
          </div>
        </div>

        {Object.keys(tokenBalances).length > 0 ? (
          <div className="space-y-4">
            {Object.entries(tokenBalances).map(([walletPublicKey, tokens]) => {
              const wallet = bundleWallets.find(w => w.publicKey === walletPublicKey);
              const displayTokens = tokens.slice(0, 3);
              const remainingCount = tokens.length - 3;

              return (
                <div key={walletPublicKey} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium">
                        {wallet?.name || `Wallet ${walletPublicKey.slice(0, 8)}...`}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {walletPublicKey.slice(0, 12)}...
                      </p>
                    </div>
                    <p className="font-medium">{wallet?.balance.toFixed(4)} SOL</p>
                  </div>
                  <div className="space-y-2">
                    {displayTokens.map((token, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="font-mono">
                          {token.mint.slice(0, 8)}...
                        </span>
                        <span>{token.amount.toFixed(token.decimals)} tokens</span>
                      </div>
                    ))}
                    {remainingCount > 0 && (
                      <p className="text-sm text-muted-foreground">
                        +{remainingCount} more tokens
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            {bundleWallets.length === 0
              ? "No bundle wallets found. Create a wallet in the bundle group first."
              : "No token balances found. Click 'Scan Tokens' to check for SPL tokens."}
          </p>
        )}
      </CardContent>
    </Card>
  );
}