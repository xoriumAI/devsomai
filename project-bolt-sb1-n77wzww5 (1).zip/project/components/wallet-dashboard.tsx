"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wallet, Coins, Archive } from "lucide-react";
import { useWalletStore } from "@/store/wallet-store";

export function WalletDashboard() {
  const { wallets, getTotalBalance } = useWalletStore();
  
  const activeWallets = wallets.filter(w => !w.archived).length;
  const archivedWallets = wallets.filter(w => w.archived).length;
  const activeBalance = getTotalBalance(false);
  const archivedBalance = getTotalBalance(true);

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Balance</CardTitle>
          <Coins className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{activeBalance.toFixed(4)} SOL</div>
          <p className="text-xs text-muted-foreground">
            In {activeWallets} active wallets
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Archived Balance</CardTitle>
          <Archive className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{archivedBalance.toFixed(4)} SOL</div>
          <p className="text-xs text-muted-foreground">
            In {archivedWallets} archived wallets
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
          <Wallet className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{(activeBalance + archivedBalance).toFixed(4)} SOL</div>
          <p className="text-xs text-muted-foreground">
            Across all {wallets.length} wallets
          </p>
        </CardContent>
      </Card>
    </div>
  );
}