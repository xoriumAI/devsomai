"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wallet, Import } from "lucide-react";
import { useWalletStore } from "@/store/wallet-store";
import { validatePrivateKey, WalletGroup, WALLET_GROUPS } from "@/lib/wallet";
import { useToast } from "@/hooks/use-toast";

interface CreateWalletDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  defaultGroup?: WalletGroup;
}

export function CreateWalletDialog({ open: controlledOpen, onOpenChange, defaultGroup = 'main' }: CreateWalletDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const { createWallet, importWallet, isLoading } = useWalletStore();
  const { toast } = useToast();

  const isControlled = controlledOpen !== undefined;
  const isOpen = isControlled ? controlledOpen : open;
  const handleOpenChange = (newOpen: boolean) => {
    if (!isControlled) {
      setOpen(newOpen);
    }
    onOpenChange?.(newOpen);
  };

  const handleCreate = async () => {
    try {
      await createWallet(name || undefined, defaultGroup);
      toast({
        title: "Success",
        description: "Wallet created successfully",
      });
      handleOpenChange(false);
      setName("");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create wallet",
        variant: "destructive",
      });
    }
  };

  const handleImport = async () => {
    if (!privateKey) {
      toast({
        title: "Error",
        description: "Please enter a private key",
        variant: "destructive",
      });
      return;
    }

    if (!validatePrivateKey(privateKey)) {
      toast({
        title: "Error",
        description: "Invalid private key format",
        variant: "destructive",
      });
      return;
    }

    try {
      await importWallet(privateKey, name || undefined, defaultGroup);
      toast({
        title: "Success",
        description: "Wallet imported successfully",
      });
      handleOpenChange(false);
      setName("");
      setPrivateKey("");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to import wallet",
        variant: "destructive",
      });
    }
  };

  const groupName = WALLET_GROUPS.find(g => g.id === defaultGroup)?.name || 'Main Wallets';

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      {!isControlled && (
        <Button onClick={() => handleOpenChange(true)}>
          <Wallet className="mr-2 h-4 w-4" />
          Add Wallet
        </Button>
      )}
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Wallet to {groupName}</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="create" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="create">Create New</TabsTrigger>
            <TabsTrigger value="import">Import Existing</TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="create-name">Wallet Name (Optional)</Label>
              <Input
                id="create-name"
                placeholder="My Wallet"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <Button onClick={handleCreate} disabled={isLoading} className="w-full">
              {isLoading ? "Creating..." : "Create Wallet"}
            </Button>
          </TabsContent>

          <TabsContent value="import" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="import-name">Wallet Name (Optional)</Label>
              <Input
                id="import-name"
                placeholder="My Imported Wallet"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="private-key">Private Key</Label>
              <Input
                id="private-key"
                type="password"
                placeholder="Enter your private key"
                value={privateKey}
                onChange={(e) => setPrivateKey(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Enter your Base58-encoded private key
              </p>
            </div>
            <Button onClick={handleImport} disabled={isLoading} className="w-full">
              {isLoading ? "Importing..." : (
                <>
                  <Import className="mr-2 h-4 w-4" />
                  Import Wallet
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}