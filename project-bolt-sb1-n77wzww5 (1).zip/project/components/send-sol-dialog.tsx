"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Send } from "lucide-react";
import { useWalletStore } from "@/store/wallet-store";
import { useToast } from "@/hooks/use-toast";
import { PublicKey } from "@solana/web3.js";

interface SendSolDialogProps {
  senderPublicKey: string;
  senderBalance: number;
}

export function SendSolDialog({ senderPublicKey, senderBalance }: SendSolDialogProps) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [recipientAddress, setRecipientAddress] = useState("");
  const { sendSOL, isLoading } = useWalletStore();
  const { toast } = useToast();

  const handleSetMaxAmount = () => {
    setAmount(senderBalance.toString());
  };

  const validateSolanaAddress = (address: string): boolean => {
    try {
      new PublicKey(address);
      return true;
    } catch {
      return false;
    }
  };

  const handleSend = async () => {
    if (!amount || !recipientAddress) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    if (!validateSolanaAddress(recipientAddress)) {
      toast({
        title: "Error",
        description: "Invalid Solana address",
        variant: "destructive",
      });
      return;
    }

    const amountNumber = parseFloat(amount);
    if (isNaN(amountNumber) || amountNumber <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (amountNumber > senderBalance) {
      toast({
        title: "Error",
        description: "Insufficient balance",
        variant: "destructive",
      });
      return;
    }

    try {
      await sendSOL(senderPublicKey, recipientAddress, amountNumber);
      toast({
        title: "Success",
        description: "Transaction sent successfully",
      });
      setOpen(false);
      setAmount("");
      setRecipientAddress("");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send SOL",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Send className="mr-2 h-4 w-4" />
          Send SOL
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send SOL</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient Address</Label>
            <Input
              id="recipient"
              placeholder="Enter Solana wallet address"
              value={recipientAddress}
              onChange={(e) => setRecipientAddress(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount (SOL)</Label>
            <Input
              id="amount"
              type="number"
              step="0.000000001"
              min="0"
              max={senderBalance}
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <p 
              className="text-sm text-muted-foreground cursor-pointer hover:text-primary transition-colors"
              onClick={handleSetMaxAmount}
              title="Click to set maximum amount"
            >
              Available balance: {senderBalance.toFixed(4)} SOL
            </p>
          </div>

          <Button 
            onClick={handleSend} 
            disabled={isLoading} 
            className="w-full"
          >
            {isLoading ? "Sending..." : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send SOL
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}