import { create } from 'zustand';
import { generateWallet, getWallets, updateWalletBalances, toggleWalletArchive, importWallet as importWalletUtil, addCEXWallet as addCEXWalletUtil, WalletGroup, sendSOL } from '@/lib/wallet';
import { withDB } from '@/lib/db';

interface Wallet {
  publicKey: string;
  name: string;
  balance: number;
  lastUpdated: Date;
  archived: boolean;
  group: WalletGroup;
}

interface WalletStore {
  wallets: Wallet[];
  isLoading: boolean;
  error: string | null;
  createWallet: (name?: string, group?: WalletGroup) => Promise<void>;
  importWallet: (privateKey: string, name?: string, group?: WalletGroup) => Promise<void>;
  addCEXWallet: (publicKey: string, name?: string) => Promise<void>;
  loadWallets: () => Promise<void>;
  refreshBalances: () => Promise<void>;
  getPrivateKey: (publicKey: string) => Promise<string>;
  toggleArchive: (publicKey: string) => Promise<void>;
  getTotalBalance: (archived?: boolean) => number;
  sendSOL: (fromPublicKey: string, toPublicKey: string, amount: number) => Promise<string>;
}

export const useWalletStore = create<WalletStore>((set, get) => ({
  wallets: [],
  isLoading: false,
  error: null,

  createWallet: async (name?: string, group: WalletGroup = 'main') => {
    try {
      set({ isLoading: true, error: null });
      await generateWallet(name, group);
      await get().loadWallets();
    } catch (error) {
      console.error('Failed to create wallet:', error);
      set({ error: 'Failed to create wallet', isLoading: false });
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },

  importWallet: async (privateKey: string, name?: string, group: WalletGroup = 'main') => {
    try {
      set({ isLoading: true, error: null });
      await importWalletUtil(privateKey, name, group);
      await get().loadWallets();
    } catch (error) {
      console.error('Failed to import wallet:', error);
      set({ error: 'Failed to import wallet', isLoading: false });
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },

  addCEXWallet: async (publicKey: string, name?: string) => {
    try {
      set({ isLoading: true, error: null });
      await addCEXWalletUtil(publicKey, name);
      await get().loadWallets();
    } catch (error) {
      console.error('Failed to add CEX wallet:', error);
      set({ error: 'Failed to add CEX wallet', isLoading: false });
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },

  loadWallets: async () => {
    try {
      set({ isLoading: true, error: null });
      const dbWallets = await getWallets();
      // Ensure the group property is of type WalletGroup
      const wallets = dbWallets.map(wallet => ({
        ...wallet,
        group: wallet.group as WalletGroup
      }));
      set({ wallets, isLoading: false });
    } catch (error) {
      console.error('Failed to load wallets:', error);
      set({ error: 'Failed to load wallets', isLoading: false });
    }
  },

  refreshBalances: async () => {
    try {
      set({ isLoading: true, error: null });
      await updateWalletBalances();
      await get().loadWallets();
    } catch (error) {
      set({ error: 'Failed to refresh balances', isLoading: false });
    } finally {
      set({ isLoading: false });
    }
  },

  getPrivateKey: async (publicKey: string) => {
    try {
      const wallet = await withDB(async (db) => {
        return db.get('wallets', publicKey);
      });
      return wallet?.encryptedPrivateKey || '';
    } catch (error) {
      console.error('Failed to get private key:', error);
      return '';
    }
  },

  toggleArchive: async (publicKey: string) => {
    try {
      set({ isLoading: true, error: null });
      await toggleWalletArchive(publicKey);
      await get().loadWallets();
    } catch (error) {
      console.error('Failed to archive wallet:', error);
      set({ error: 'Failed to archive wallet', isLoading: false });
    } finally {
      set({ isLoading: false });
    }
  },

  getTotalBalance: (archived?: boolean) => {
    const wallets = get().wallets;
    return wallets
      .filter(w => archived === undefined || w.archived === archived)
      .reduce((sum, wallet) => sum + wallet.balance, 0);
  },

  sendSOL: async (fromPublicKey: string, toPublicKey: string, amount: number) => {
    try {
      set({ isLoading: true, error: null });
      const signature = await sendSOL(fromPublicKey, toPublicKey, amount);
      await get().refreshBalances();
      return signature;
    } catch (error) {
      set({ error: 'Failed to send SOL', isLoading: false });
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },
}));