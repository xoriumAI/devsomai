// This file is no longer needed as we're using IndexedDB
export {};